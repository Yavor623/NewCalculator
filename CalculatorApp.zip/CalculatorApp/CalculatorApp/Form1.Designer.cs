﻿namespace CalculatorApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            tableLayoutPanel1 = new TableLayoutPanel();
            equalbtn = new Button();
            commabtn = new Button();
            zerobtn = new Button();
            negatebtn = new Button();
            plusbtn = new Button();
            threebtn = new Button();
            twobtn = new Button();
            onebtn = new Button();
            minusbtn = new Button();
            sixbtn = new Button();
            fivebtn = new Button();
            fourbtn = new Button();
            multiplicationbtn = new Button();
            ninebtn = new Button();
            eightbtn = new Button();
            sevenbtn = new Button();
            dividebtn = new Button();
            button7 = new Button();
            byThePowerOf2btn = new Button();
            deletexby1btn = new Button();
            removeLastOnebtn = new Button();
            removeAllbtn = new Button();
            removeLastbtn = new Button();
            percentbtn = new Button();
            resulttxt = new TextBox();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = Color.LightSalmon;
            tableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel1.ColumnCount = 4;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25.00062F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25.0006275F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25.0006275F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 24.9981251F));
            tableLayoutPanel1.Controls.Add(equalbtn, 3, 5);
            tableLayoutPanel1.Controls.Add(commabtn, 2, 5);
            tableLayoutPanel1.Controls.Add(zerobtn, 1, 5);
            tableLayoutPanel1.Controls.Add(negatebtn, 0, 5);
            tableLayoutPanel1.Controls.Add(plusbtn, 3, 4);
            tableLayoutPanel1.Controls.Add(threebtn, 2, 4);
            tableLayoutPanel1.Controls.Add(twobtn, 1, 4);
            tableLayoutPanel1.Controls.Add(onebtn, 0, 4);
            tableLayoutPanel1.Controls.Add(minusbtn, 3, 3);
            tableLayoutPanel1.Controls.Add(sixbtn, 2, 3);
            tableLayoutPanel1.Controls.Add(fivebtn, 1, 3);
            tableLayoutPanel1.Controls.Add(fourbtn, 0, 3);
            tableLayoutPanel1.Controls.Add(multiplicationbtn, 3, 2);
            tableLayoutPanel1.Controls.Add(ninebtn, 2, 2);
            tableLayoutPanel1.Controls.Add(eightbtn, 1, 2);
            tableLayoutPanel1.Controls.Add(sevenbtn, 0, 2);
            tableLayoutPanel1.Controls.Add(dividebtn, 3, 1);
            tableLayoutPanel1.Controls.Add(button7, 2, 1);
            tableLayoutPanel1.Controls.Add(byThePowerOf2btn, 1, 1);
            tableLayoutPanel1.Controls.Add(deletexby1btn, 0, 1);
            tableLayoutPanel1.Controls.Add(removeLastOnebtn, 3, 0);
            tableLayoutPanel1.Controls.Add(removeAllbtn, 2, 0);
            tableLayoutPanel1.Controls.Add(removeLastbtn, 1, 0);
            tableLayoutPanel1.Controls.Add(percentbtn, 0, 0);
            tableLayoutPanel1.Dock = DockStyle.Bottom;
            tableLayoutPanel1.GrowStyle = TableLayoutPanelGrowStyle.FixedSize;
            tableLayoutPanel1.Location = new Point(0, 177);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 7;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 14.2857141F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 14.2857141F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 14.2857141F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 14.2857141F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 14.2857141F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 14.2857141F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 14.2857141F));
            tableLayoutPanel1.Size = new Size(889, 434);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // equalbtn
            // 
            equalbtn.BackColor = Color.Maroon;
            equalbtn.Cursor = Cursors.Hand;
            equalbtn.Dock = DockStyle.Fill;
            equalbtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            equalbtn.Location = new Point(670, 309);
            equalbtn.Name = "equalbtn";
            equalbtn.Size = new Size(215, 54);
            equalbtn.TabIndex = 23;
            equalbtn.Text = "=";
            equalbtn.UseVisualStyleBackColor = false;
            equalbtn.Click += equalbtn_Click;
            // 
            // commabtn
            // 
            commabtn.BackColor = Color.OrangeRed;
            commabtn.Cursor = Cursors.Hand;
            commabtn.Dock = DockStyle.Fill;
            commabtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            commabtn.Location = new Point(448, 309);
            commabtn.Name = "commabtn";
            commabtn.Size = new Size(215, 54);
            commabtn.TabIndex = 22;
            commabtn.Text = ",";
            commabtn.UseVisualStyleBackColor = false;
            // 
            // zerobtn
            // 
            zerobtn.BackColor = Color.LightCoral;
            zerobtn.Cursor = Cursors.Hand;
            zerobtn.Dock = DockStyle.Fill;
            zerobtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            zerobtn.Location = new Point(226, 309);
            zerobtn.Name = "zerobtn";
            zerobtn.Size = new Size(215, 54);
            zerobtn.TabIndex = 21;
            zerobtn.Text = "0";
            zerobtn.UseVisualStyleBackColor = false;
            zerobtn.Click += zerobtn_Click;
            // 
            // negatebtn
            // 
            negatebtn.BackColor = Color.OrangeRed;
            negatebtn.Cursor = Cursors.Hand;
            negatebtn.Dock = DockStyle.Fill;
            negatebtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            negatebtn.Location = new Point(4, 309);
            negatebtn.Name = "negatebtn";
            negatebtn.Size = new Size(215, 54);
            negatebtn.TabIndex = 20;
            negatebtn.Text = "+/-";
            negatebtn.UseVisualStyleBackColor = false;
            negatebtn.Click += negatebtn_Click;
            // 
            // plusbtn
            // 
            plusbtn.BackColor = Color.OrangeRed;
            plusbtn.Cursor = Cursors.Hand;
            plusbtn.Dock = DockStyle.Fill;
            plusbtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            plusbtn.Location = new Point(670, 248);
            plusbtn.Name = "plusbtn";
            plusbtn.Size = new Size(215, 54);
            plusbtn.TabIndex = 19;
            plusbtn.Text = "+";
            plusbtn.UseVisualStyleBackColor = false;
            plusbtn.Click += plusbtn_Click;
            // 
            // threebtn
            // 
            threebtn.BackColor = Color.LightCoral;
            threebtn.Cursor = Cursors.Hand;
            threebtn.Dock = DockStyle.Fill;
            threebtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            threebtn.Location = new Point(448, 248);
            threebtn.Name = "threebtn";
            threebtn.Size = new Size(215, 54);
            threebtn.TabIndex = 18;
            threebtn.Text = "3";
            threebtn.UseVisualStyleBackColor = false;
            threebtn.Click += threebtn_Click;
            // 
            // twobtn
            // 
            twobtn.BackColor = Color.LightCoral;
            twobtn.Cursor = Cursors.Hand;
            twobtn.Dock = DockStyle.Fill;
            twobtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            twobtn.Location = new Point(226, 248);
            twobtn.Name = "twobtn";
            twobtn.Size = new Size(215, 54);
            twobtn.TabIndex = 17;
            twobtn.Text = "2";
            twobtn.UseVisualStyleBackColor = false;
            twobtn.Click += twobtn_Click;
            // 
            // onebtn
            // 
            onebtn.BackColor = Color.LightCoral;
            onebtn.Cursor = Cursors.Hand;
            onebtn.Dock = DockStyle.Fill;
            onebtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            onebtn.Location = new Point(4, 248);
            onebtn.Name = "onebtn";
            onebtn.Size = new Size(215, 54);
            onebtn.TabIndex = 16;
            onebtn.Text = "1";
            onebtn.UseVisualStyleBackColor = false;
            onebtn.Click += onebtn_Click;
            // 
            // minusbtn
            // 
            minusbtn.BackColor = Color.OrangeRed;
            minusbtn.Cursor = Cursors.Hand;
            minusbtn.Dock = DockStyle.Fill;
            minusbtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            minusbtn.Location = new Point(670, 187);
            minusbtn.Name = "minusbtn";
            minusbtn.Size = new Size(215, 54);
            minusbtn.TabIndex = 15;
            minusbtn.Text = "-";
            minusbtn.UseVisualStyleBackColor = false;
            minusbtn.Click += minusbtn_Click;
            // 
            // sixbtn
            // 
            sixbtn.BackColor = Color.LightCoral;
            sixbtn.Cursor = Cursors.Hand;
            sixbtn.Dock = DockStyle.Fill;
            sixbtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            sixbtn.Location = new Point(448, 187);
            sixbtn.Name = "sixbtn";
            sixbtn.Size = new Size(215, 54);
            sixbtn.TabIndex = 14;
            sixbtn.Text = "6";
            sixbtn.UseVisualStyleBackColor = false;
            sixbtn.Click += sixbtn_Click;
            // 
            // fivebtn
            // 
            fivebtn.BackColor = Color.LightCoral;
            fivebtn.Cursor = Cursors.Hand;
            fivebtn.Dock = DockStyle.Fill;
            fivebtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            fivebtn.Location = new Point(226, 187);
            fivebtn.Name = "fivebtn";
            fivebtn.Size = new Size(215, 54);
            fivebtn.TabIndex = 13;
            fivebtn.Text = "5";
            fivebtn.UseVisualStyleBackColor = false;
            fivebtn.Click += fivebtn_Click;
            // 
            // fourbtn
            // 
            fourbtn.BackColor = Color.LightCoral;
            fourbtn.Cursor = Cursors.Hand;
            fourbtn.Dock = DockStyle.Fill;
            fourbtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            fourbtn.Location = new Point(4, 187);
            fourbtn.Name = "fourbtn";
            fourbtn.Size = new Size(215, 54);
            fourbtn.TabIndex = 12;
            fourbtn.Text = "4";
            fourbtn.UseVisualStyleBackColor = false;
            fourbtn.Click += fourbtn_Click;
            // 
            // multiplicationbtn
            // 
            multiplicationbtn.BackColor = Color.OrangeRed;
            multiplicationbtn.Cursor = Cursors.Hand;
            multiplicationbtn.Dock = DockStyle.Fill;
            multiplicationbtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            multiplicationbtn.Location = new Point(670, 126);
            multiplicationbtn.Name = "multiplicationbtn";
            multiplicationbtn.Size = new Size(215, 54);
            multiplicationbtn.TabIndex = 11;
            multiplicationbtn.Text = "×";
            multiplicationbtn.UseVisualStyleBackColor = false;
            multiplicationbtn.Click += multiplicationbtn_Click;
            // 
            // ninebtn
            // 
            ninebtn.BackColor = Color.LightCoral;
            ninebtn.Cursor = Cursors.Hand;
            ninebtn.Dock = DockStyle.Fill;
            ninebtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            ninebtn.Location = new Point(448, 126);
            ninebtn.Name = "ninebtn";
            ninebtn.Size = new Size(215, 54);
            ninebtn.TabIndex = 10;
            ninebtn.Text = "9";
            ninebtn.UseVisualStyleBackColor = false;
            ninebtn.Click += ninebtn_Click;
            // 
            // eightbtn
            // 
            eightbtn.BackColor = Color.LightCoral;
            eightbtn.Cursor = Cursors.Hand;
            eightbtn.Dock = DockStyle.Fill;
            eightbtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            eightbtn.Location = new Point(226, 126);
            eightbtn.Name = "eightbtn";
            eightbtn.Size = new Size(215, 54);
            eightbtn.TabIndex = 9;
            eightbtn.Text = "8";
            eightbtn.UseVisualStyleBackColor = false;
            eightbtn.Click += eightbtn_Click;
            // 
            // sevenbtn
            // 
            sevenbtn.BackColor = Color.LightCoral;
            sevenbtn.Cursor = Cursors.Hand;
            sevenbtn.Dock = DockStyle.Fill;
            sevenbtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            sevenbtn.Location = new Point(4, 126);
            sevenbtn.Name = "sevenbtn";
            sevenbtn.Size = new Size(215, 54);
            sevenbtn.TabIndex = 8;
            sevenbtn.Text = "7";
            sevenbtn.UseVisualStyleBackColor = false;
            sevenbtn.Click += sevenbtn_Click;
            // 
            // dividebtn
            // 
            dividebtn.BackColor = Color.OrangeRed;
            dividebtn.Cursor = Cursors.Hand;
            dividebtn.Dock = DockStyle.Fill;
            dividebtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            dividebtn.Location = new Point(670, 65);
            dividebtn.Name = "dividebtn";
            dividebtn.Size = new Size(215, 54);
            dividebtn.TabIndex = 7;
            dividebtn.Text = "÷";
            dividebtn.UseVisualStyleBackColor = false;
            dividebtn.Click += dividebtn_Click;
            // 
            // button7
            // 
            button7.BackColor = Color.OrangeRed;
            button7.Cursor = Cursors.Hand;
            button7.Dock = DockStyle.Fill;
            button7.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            button7.Location = new Point(448, 65);
            button7.Name = "button7";
            button7.RightToLeft = RightToLeft.No;
            button7.Size = new Size(215, 54);
            button7.TabIndex = 6;
            button7.Text = "²√x";
            button7.UseVisualStyleBackColor = false;
            // 
            // byThePowerOf2btn
            // 
            byThePowerOf2btn.BackColor = Color.OrangeRed;
            byThePowerOf2btn.Cursor = Cursors.Hand;
            byThePowerOf2btn.Dock = DockStyle.Fill;
            byThePowerOf2btn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            byThePowerOf2btn.Location = new Point(226, 65);
            byThePowerOf2btn.Name = "byThePowerOf2btn";
            byThePowerOf2btn.Size = new Size(215, 54);
            byThePowerOf2btn.TabIndex = 5;
            byThePowerOf2btn.Text = "x²";
            byThePowerOf2btn.UseVisualStyleBackColor = false;
            // 
            // deletexby1btn
            // 
            deletexby1btn.BackColor = Color.OrangeRed;
            deletexby1btn.Cursor = Cursors.Hand;
            deletexby1btn.Dock = DockStyle.Fill;
            deletexby1btn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            deletexby1btn.Location = new Point(4, 65);
            deletexby1btn.Name = "deletexby1btn";
            deletexby1btn.Size = new Size(215, 54);
            deletexby1btn.TabIndex = 4;
            deletexby1btn.Text = "1/x";
            deletexby1btn.UseVisualStyleBackColor = false;
            // 
            // removeLastOnebtn
            // 
            removeLastOnebtn.BackColor = Color.Maroon;
            removeLastOnebtn.Cursor = Cursors.Hand;
            removeLastOnebtn.Dock = DockStyle.Fill;
            removeLastOnebtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            removeLastOnebtn.Location = new Point(670, 4);
            removeLastOnebtn.Name = "removeLastOnebtn";
            removeLastOnebtn.Size = new Size(215, 54);
            removeLastOnebtn.TabIndex = 3;
            removeLastOnebtn.Text = "<=";
            removeLastOnebtn.UseVisualStyleBackColor = false;
            removeLastOnebtn.Click += removeLastOnebtn_Click;
            // 
            // removeAllbtn
            // 
            removeAllbtn.BackColor = Color.Maroon;
            removeAllbtn.Cursor = Cursors.Hand;
            removeAllbtn.Dock = DockStyle.Fill;
            removeAllbtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            removeAllbtn.Location = new Point(448, 4);
            removeAllbtn.Name = "removeAllbtn";
            removeAllbtn.Size = new Size(215, 54);
            removeAllbtn.TabIndex = 2;
            removeAllbtn.Text = "C";
            removeAllbtn.UseVisualStyleBackColor = false;
            removeAllbtn.Click += removeAllbtn_Click;
            // 
            // removeLastbtn
            // 
            removeLastbtn.BackColor = Color.Maroon;
            removeLastbtn.Cursor = Cursors.Hand;
            removeLastbtn.Dock = DockStyle.Fill;
            removeLastbtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            removeLastbtn.Location = new Point(226, 4);
            removeLastbtn.Name = "removeLastbtn";
            removeLastbtn.Size = new Size(215, 54);
            removeLastbtn.TabIndex = 1;
            removeLastbtn.Text = "CE";
            removeLastbtn.UseVisualStyleBackColor = false;
            // 
            // percentbtn
            // 
            percentbtn.BackColor = Color.OrangeRed;
            percentbtn.Cursor = Cursors.Hand;
            percentbtn.Dock = DockStyle.Fill;
            percentbtn.Font = new Font("Microsoft Sans Serif", 20F, FontStyle.Regular, GraphicsUnit.Point);
            percentbtn.Location = new Point(4, 4);
            percentbtn.Name = "percentbtn";
            percentbtn.Size = new Size(215, 54);
            percentbtn.TabIndex = 0;
            percentbtn.Text = "%";
            percentbtn.UseVisualStyleBackColor = false;
            // 
            // resulttxt
            // 
            resulttxt.BackColor = Color.LightGray;
            resulttxt.Font = new Font("Segoe UI", 40F, FontStyle.Regular, GraphicsUnit.Point);
            resulttxt.Location = new Point(258, 53);
            resulttxt.Multiline = true;
            resulttxt.Name = "resulttxt";
            resulttxt.ReadOnly = true;
            resulttxt.RightToLeft = RightToLeft.No;
            resulttxt.Size = new Size(619, 91);
            resulttxt.TabIndex = 1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(889, 611);
            Controls.Add(resulttxt);
            Controls.Add(tableLayoutPanel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MinimumSize = new Size(378, 658);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Calculator";
            Load += Form1_Load;
            tableLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Button percentbtn;
        private Button equalbtn;
        private Button commabtn;
        private Button zerobtn;
        private Button negatebtn;
        private Button plusbtn;
        private Button threebtn;
        private Button twobtn;
        private Button onebtn;
        private Button minusbtn;
        private Button sixbtn;
        private Button fivebtn;
        private Button fourbtn;
        private Button multiplicationbtn;
        private Button ninebtn;
        private Button eightbtn;
        private Button sevenbtn;
        private Button dividebtn;
        private Button button7;
        private Button byThePowerOf2btn;
        private Button deletexby1btn;
        private Button removeLastOnebtn;
        private Button removeAllbtn;
        private Button removeLastbtn;
        private TextBox resulttxt;
    }
}