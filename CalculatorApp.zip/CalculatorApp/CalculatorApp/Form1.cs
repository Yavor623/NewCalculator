using CalculatorLogic;
namespace CalculatorApp
{
    public partial class Form1 : Form
    {
        private Calculations logic;
        private string firstNumber;
        private string secondNumber;
        private string operation;
        public Form1()
        {
            InitializeComponent();
            logic = new Calculations();
            firstNumber = string.Empty;
            secondNumber = string.Empty;
            operation = string.Empty;
        }
        string result;

        public Form1(string firstNumber, string secondNumber, string operation)
        {
            this.firstNumber = firstNumber;
            this.secondNumber = secondNumber;
            this.operation = operation;
        }
        private void onebtn_Click(object sender, EventArgs e)
        {
            resulttxt.Text += "1";
        }

        private void twobtn_Click(object sender, EventArgs e)
        {
            resulttxt.Text += "2";
        }



        private void sixbtn_Click(object sender, EventArgs e)
        {
            resulttxt.Text += "6";
        }

        private void fivebtn_Click(object sender, EventArgs e)
        {
            resulttxt.Text += "5";
        }

        private void fourbtn_Click(object sender, EventArgs e)
        {
            resulttxt.Text += "4";
        }

        private void sevenbtn_Click(object sender, EventArgs e)
        {
            resulttxt.Text += "7";
        }

        private void eightbtn_Click(object sender, EventArgs e)
        {
            resulttxt.Text += "8";
        }

        private void ninebtn_Click(object sender, EventArgs e)
        {
            resulttxt.Text += "9";
        }

        private void equalbtn_Click(object sender, EventArgs e)
        {
            MainOperation();
            resulttxt.Text = result;
        }

        private void plusbtn_Click(object sender, EventArgs e)
        {
            this.firstNumber = resulttxt.Text;
            operation = "+";
            resulttxt.Text = string.Empty;


        }

        private void minusbtn_Click(object sender, EventArgs e)
        {
            this.firstNumber = resulttxt.Text;

            operation = "-";
            resulttxt.Text = string.Empty;

        }

        private void removeAllbtn_Click(object sender, EventArgs e)
        {
            resulttxt.Text = string.Empty;
        }

        private void zerobtn_Click(object sender, EventArgs e)
        {
            if (resulttxt.Text != "0")
            {
                resulttxt.Text += "0";
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button_Click(object sender, EventArgs e)
        {

        }
        public void MainOperation()
        {
            if (operation != null)
            {
                this.secondNumber = resulttxt.Text;
                switch (operation)
                {
                    case "+":
                        double fn;
                        double.TryParse(firstNumber, out fn);
                        double sn;
                        double.TryParse(secondNumber, out sn);
                        double finalResult = logic.Adding(fn, sn);
                        result = $"{finalResult}";
                        break;
                    case "-":
                        double fn1;
                        double.TryParse(firstNumber, out fn1);
                        double sn1;
                        double.TryParse(secondNumber, out sn1);
                        double finalResult1 = logic.Substraction(fn1, sn1);
                        result = $"{finalResult1}";
                        break;
                        break;
                    case "*":
                        double fn2;
                        double.TryParse(firstNumber, out fn2);
                        double sn2;
                        double.TryParse(secondNumber, out sn2);
                        double finalResult2 = logic.Multiplicaton(fn2, sn2);
                        result = $"{finalResult2}";
                        break;
                    case "/":
                        double fn3;
                        double.TryParse(firstNumber, out fn3);
                        double sn3;
                        double.TryParse(secondNumber, out sn3);
                        string finalResult3 = logic.Division(fn3, sn3);
                        result = finalResult3;
                        break;
                }
            }


        }

        private void threebtn_Click(object sender, EventArgs e)
        {
            resulttxt.Text += "3";

        }

        private void multiplicationbtn_Click(object sender, EventArgs e)
        {
            this.firstNumber = resulttxt.Text;

            operation = "*";
            resulttxt.Text = string.Empty;
        }

        private void dividebtn_Click(object sender, EventArgs e)
        {
            this.firstNumber = resulttxt.Text;

            operation = "/";
            resulttxt.Text = string.Empty;
        }

        private void negatebtn_Click(object sender, EventArgs e)
        {
            resulttxt.Text = $"-{resulttxt.Text}";
        }

        private void removeLastOnebtn_Click(object sender, EventArgs e)
        {

        }
    }
}